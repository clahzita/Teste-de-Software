
public class CircularBufferException extends RuntimeException {
	
	public CircularBufferException(String message) {
		super(message);
	}
}
