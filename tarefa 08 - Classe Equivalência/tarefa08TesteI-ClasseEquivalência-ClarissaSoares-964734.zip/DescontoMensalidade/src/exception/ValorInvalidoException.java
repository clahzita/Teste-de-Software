package exception;

@SuppressWarnings("serial")
public class ValorInvalidoException extends Exception {

}
