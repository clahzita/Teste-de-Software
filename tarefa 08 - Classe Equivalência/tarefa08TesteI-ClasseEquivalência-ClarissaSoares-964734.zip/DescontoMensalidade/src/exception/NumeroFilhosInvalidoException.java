package exception;

@SuppressWarnings("serial")
public class NumeroFilhosInvalidoException extends Exception {

}
