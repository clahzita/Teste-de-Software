package banco;

public class OperacaoIlegalException extends Exception {

}

